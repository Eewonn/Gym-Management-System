<div class="datetime">
    <?php
        echo date('l jS \of F Y - h:i:s A');
    ?>
</div>
